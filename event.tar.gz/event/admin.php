<h2>LOGIN</h2>
        <form action="adminlogin.php" method="post"  enctype="multipart/form-data">
  <div class="form-group">
    <label for="exampleInputusername">NAME</label>
    <input type="name" name="name" class="form-control" id="exampleInputEmail1" placeholder="name">
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">PASSWORD</label>
    <input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="password">
  </div>
 
  <input type="submit"  value="login" name="login">
</form>
